using System.Collections;
using UnityEngine;

namespace Sunward.Remaster
{
    public sealed class VillageServices : MonoBehaviour
    {
        public GameFlow game;
        public bool Resting { get; private set; }
        public void CancelRest()
        {
            if(!Resting)return;
            StopAllCoroutines();Resting=false;
            if(game && game.Player)game.Player.Locked=false;
        }
        public static readonly Vector3 DojoDoor=new Vector3(0,.5f,15.1f), FoodDoor=new Vector3(4.8f,.4f,-15), Mat=new Vector3(8,.4f,-13.4f), Farmer=new Vector3(37,0,21.7f);
        public static Vector3 FarmerPosition {get{foreach(var r in Object.FindObjectsByType<NativeDailyRoutine>(FindObjectsSortMode.None))if(r.farmer)return r.transform.position;return Farmer;}}
        public static bool InDojo(Vector3 p)=>VillageInteriors.Dojo(p);
        public static bool InFoodHouse(Vector3 p)=>VillageInteriors.Food(p);
        static readonly RaycastHit[] floorHits=new RaycastHit[32];
        public static bool Floor(Vector3 p,out float height)
        {
            bool dojo=InDojo(p);height=dojo?.50f:.40f;
            if(!dojo && !InFoodHouse(p))return false;
            // The original dojo has bevels/slopes, not a flat two-level floor.
            // Use its real mesh collision for the existing player controller.
            if(VillageInteriors.Height(p,out var indoor)){height=indoor;return true;}
            int n=Physics.RaycastNonAlloc(new Ray(new Vector3(p.x,5.5f,p.z),Vector3.down),floorHits,9,1<<6,QueryTriggerInteraction.Ignore);
            bool found=false;
            for(int i=0;i<n;i++)
            {
                var hit=floorHits[i];string name=hit.collider.name;
                if(dojo?!name.Contains("dojo-floor"):!name.Contains("food house floor"))continue;
                if(!found || hit.point.y>height){height=hit.point.y;found=true;}
            }
            return true;
        }
        public static string Label(string action,Vector3 p)
        {
            if(action=="venue:dojo")return InDojo(p)?"E · Leave the training hall":"E · Enter the samurai training hall";
            if(action=="venue:food")return InFoodHouse(p)?"E · Leave the food house":"E · Enter the food & music house";
            if(action=="venue:pond")return "E · Rest beside the steaming pond";
            if(action=="venue:mat")return "E · Sit on Amaterasu's mat";
            return "E · Speak with the farmer";
        }
        void Awake(){if(!game)game=GetComponent<GameFlow>();}
        public void Interact(string action)
        {
            if(Resting || !game)return;
            if(action=="venue:dojo")VillageInteriors.Enter(game,"dojo");
            else if(action=="venue:food")VillageInteriors.Enter(game,"food");
            else if(action=="venue:mat")StartCoroutine(Sit());
            else if(action=="venue:pond")RestAt(new Vector3(GardenPond.X+3.7f,.04f,GardenPond.Z),270);
            else if(action=="venue:farmer") {game.Audio.Npc(3,FarmerPosition);game.SetPanel("farm");}
            if(action=="venue:dojo" || action=="venue:food")
            {
                var camera=FindFirstObjectByType<OrbitCamera>();if(camera)camera.SnapFocus();
            }
            game.Combat.Equip();
        }
        public void RestAt(Vector3 point,float yaw){if(!Resting)StartCoroutine(SitAt(point,yaw));}
        IEnumerator Sit(){yield return SitAt(VillageInteriors.Mat,90);}
        IEnumerator SitAt(Vector3 point,float yaw)
        {
            Resting=true;game.Player.Locked=true;game.Combat.Cancel();game.Combat.Rest(true);
            game.Player.Teleport(point);game.Player.transform.rotation=Quaternion.Euler(0,yaw,0);
            game.Player.animationView.Play("Sit",.18f,0,true);game.Notify("Rest quietly · E or movement to stand");
            yield return null;
            while(!game.Player.input.Interact.WasPressedThisFrame() && !game.Player.input.Jump.WasPressedThisFrame() && !game.Player.input.Pause.WasPressedThisFrame() && game.Player.input.Move.ReadValue<Vector2>().sqrMagnitude<.1f)
            {game.Health=Mathf.Min(game.MaxHealth,game.Health+Time.deltaTime*3);yield return null;}
            game.Player.Locked=false;game.Player.animationView.Play("Idle_Natural",.15f,0,true);
            game.Combat.Rest(false);Resting=false;
        }
    }
}
