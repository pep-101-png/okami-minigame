SUNWARD EXISTING-GAME REPAIR CANDIDATE — 31 October 2026

Source commit: 045e48e7f07054b81876c58fe5975cb4616c3139
Cumulative update against integration baseline: 00fd8695363df01de80b012d68feb20c9961e8a9
Previous playtested source / rollback: 262519a7ac762e4e1f5af7f472139cedf87f8bd9

1. Close Unity and back up your complete current Sunward project.
2. Extract this ZIP into a temporary folder.
3. Merge Assets (and any other project folders included) into your EXISTING Sunward project, replacing matching files.
4. KEEP the rest of your project. Do not delete or replace the whole Assets folder.
5. Open the existing Windflower scene and Play normally. This is not a separate demo scene or a complete standalone Unity project.

Repair-Report contains the full 12-item follow-up checklist, source provenance, offline check results and labelled Blender previews.
Controls: E use/enter venues and sitting mat; Q cycle owned weapons; P toggle original Shiranui appearance; river swimming uses normal movement.

OFFLINE CHECKS PASSED. UNITY COMPILATION AND PLAYBACK ARE UNVERIFIED for this candidate.
Dedicated native koto finger-playing motion is unidentified. The existing swim clips are retained with deeper immersion/slower strokes; their original action identities are not confirmed. Full native EST/SEQ dispatch and original font rendering also remain unfinished.
Sound sources are original. All 42 active cues have been rebuilt, correcting 39 encrypted ADX streams; final cue timing/meaning and balance still need audible play testing.

This cumulative update includes the previous original-asset remake dependencies. Existing unrelated project files and user saves are not packaged.
