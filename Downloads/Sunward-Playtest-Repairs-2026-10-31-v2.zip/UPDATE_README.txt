SUNWARD EXISTING-GAME REPAIR CANDIDATE — 31 October 2026

Source commit: 1a47fd212f238f7cfa54eea5cc82c63481ddcb9b
Cumulative update against integration baseline: 00fd8695363df01de80b012d68feb20c9961e8a9
Previous playtested source / rollback: 045e48e7f07054b81876c58fe5975cb4616c3139

1. Close Unity and back up your complete current Sunward project.
2. Extract this ZIP into a temporary folder.
3. Merge Assets (and any other project folders included) into your EXISTING Sunward project, replacing matching files.
4. KEEP the rest of your project. Do not delete or replace the whole Assets folder.
5. Open the existing Windflower scene and Play normally. This is not a separate demo scene or a complete standalone Unity project.

Repair-Report contains the actual issue checklist, original motion provenance, offline check results and labelled Blender diagnostics.
Controls: E use/enter venues and sitting mat; Q cycle owned weapons; P toggle original Shiranui appearance; river swimming uses normal movement.

OFFLINE CHECKS PASSED. UNITY COMPILATION, PLAYBACK AND AUDIBLE BALANCE ARE UNVERIFIED.
Village/pub background music is currently silent pending positive native track identification. The arena now uses the long track identified as battle by the playtester; the short cleansing/result cue is not looped.
Swimming now uses a different original source clip, pl00_013. Its original action identity and convincing Unity swimming remain unconfirmed. Dedicated koto finger-playing, complete native combat/effect dispatch and original UI fonts remain unfinished.
See Repair-Report/README.md for the changes and exact limits. This is a candidate for testing, not a verified finished remaster.

This cumulative update includes the previous original-asset remake dependencies. Existing unrelated project files and user saves are not packaged.
