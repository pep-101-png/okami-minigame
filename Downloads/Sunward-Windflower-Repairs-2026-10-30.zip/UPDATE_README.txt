SUNWARD EXISTING-GAME REPAIR CANDIDATE — 30 October 2026

Source commit: 262519a7ac762e4e1f5af7f472139cedf87f8bd9
Cumulative update against integration baseline: 00fd8695363df01de80b012d68feb20c9961e8a9
Previous playtested source / rollback: 72336e1aa558d1344c1b52b93bac882b3dd31eb4

1. Close Unity and back up your complete current Sunward project.
2. Extract this ZIP into a temporary folder.
3. Merge Assets (and any other project folders included) into your EXISTING Sunward project, replacing matching files.
4. KEEP the rest of your project. Do not delete or replace the whole Assets folder.
5. Open the existing Windflower scene and Play normally. This is not a separate demo scene or a complete standalone Unity project.

Repair-Report contains the full 20-item checklist, source provenance, offline check results and labelled Blender previews.
Controls: E use/enter venues and sitting mat; Q cycle owned weapons; P toggle original Shiranui appearance; river swimming uses normal movement.

OFFLINE CHECKS PASSED. UNITY COMPILATION AND PLAYBACK ARE UNVERIFIED for this candidate.
Full original EST/SEQ effects (including exact Shiranui/Solar Flare sequences), dedicated instrument-playing motion and original UI font rendering remain unfinished.
Sound sources are original; exact cue mapping/timing/music identity and balance need audible play testing.

This cumulative update includes the previous original-asset remake dependencies. Existing unrelated project files and user saves are not packaged.
