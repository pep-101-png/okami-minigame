SUNWARD ORIGINAL-ASSET UPDATE - 30 October 2026

IMPLEMENTED SOURCE CANDIDATE. NOT UNITY-VERIFIED OR A FINISHED REMASTER.

This updates your existing Sunward project and existing playable Windflower scene.
It does not add a replacement demo scene.

1. Close Unity and back up your current Sunward project.
2. Extract this ZIP and MERGE its Assets folder into your existing Sunward-Unity
   project folder (the folder containing Assets, Packages and ProjectSettings).
   Replace matching files. KEEP all other existing files. Do not delete Assets.
3. Open that existing project in Unity. Open Assets/Sunward/Scenes/Windflower.unity
   if it is not already open, then use the normal Play button.

This is an update, not a complete standalone Unity project. The current GitHub
working branch and your existing saves are not replaced by downloading it.
The source changes are isolated on a remaster branch pending actual Unity review.

Original houses, markets, human NPC appearances, enemy appearances and motions,
vegetation, props, native player and weapon resources are included. Existing
layout, colliders, controller, combat values, progression and save IDs are retained.
Full Solar Flare effects, authentic music/ambient/general effect banks and original
UI fonts remain unfinished. Missing sounds are silent, not synthesized substitutes.
Runtime animation/action/attachment/visibility approval is still required.

There is no Unity editor in the authoring cloud. C# syntax and offline references
passed; this does not prove Unity compilation or gameplay. The included previews
are explicitly labelled BLENDER diagnostics, NOT Unity gameplay screenshots.

See Remake-Report/README.md and the source manifests for the full report.
Source commit: 72336e1aa558d1344c1b52b93bac882b3dd31eb4
Base working-game commit: 00fd8695363df01de80b012d68feb20c9961e8a9
