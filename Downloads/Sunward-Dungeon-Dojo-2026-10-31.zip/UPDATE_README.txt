SUNWARD DUNGEON / DOJO PATCH — 31 October 2026

Source commit: 472f7be2fbaa29ed7d1827eca563ee4033e65c35
Requires preceding Combat / Lower Arena update, source 9646fda1fd46017f6627c8f815cdb32382b2d73e.

Close Unity; back up your existing working project. Extract this ZIP, then MERGE its Assets folder into the EXISTING project, replacing matching files. KEEP all other project files. Do not delete the original Assets folder. Open existing Windflower and Play. This is a focused incremental patch, not a standalone Unity project.

Original r10d boss-stage floor/shrine/cavern, red/amber lights and original flame/mist sprites replace previous lower decor. A real 34m earth shaft matches the irregular broken terrain. Chamber floor is about 110m below village; highest wall remains 28m below ground. Win upper arena, Explore, jump down, E at mirror returns home. No downstairs bosses.

Three dojo pairs receive isolated native model selections, original draw/aim clips and animated support-foot correction. No changes to weapon mechanics, audio balance, home/market, save data or combat statistics.

Full report, source hashes, exact motions, limitations, offline verification and LABELLED BLENDER PREVIEWS are in Repair-Report.

UNITY COMPILATION / PLAYBACK / LIGHTING / PERFORMANCE UNVERIFIED here. Geometry, full-cycle skin-support checks and C# syntax checked offline. Draw/aim drills are not a verified continuous dummy-striking choreography. Original EST/SEQ event system is not fully reconstructed.
