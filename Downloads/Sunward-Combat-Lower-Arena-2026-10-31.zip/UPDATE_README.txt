SUNWARD EXISTING-GAME REPAIR CANDIDATE — 31 October 2026

Source commit: 9646fda1fd46017f6627c8f815cdb32382b2d73e
Cumulative update against integration baseline: 00fd8695363df01de80b012d68feb20c9961e8a9
Previous playtested source / rollback: 1a47fd212f238f7cfa54eea5cc82c63481ddcb9b

1. Close Unity and back up your complete current Sunward project.
2. Extract this ZIP into a temporary folder.
3. Merge Assets (and any other project folders included) into your EXISTING Sunward project, replacing matching files.
4. KEEP the rest of your project. Do not delete or replace the whole Assets folder.
5. Open the existing Windflower scene and Play normally. This is not a separate demo scene or a complete standalone Unity project.

Repair-Report contains the complete latest issue checklist, original motion/model/audio provenance, geometry checks and labelled Blender diagnostics.
Controls: E use/enter, Q cycle owned instruments, P Shiranui, normal movement/swimming.

Win the upper trial and choose EXPLORE THE LOWER ARENA. Jump through the broken centre floor. Use E near the mirror below to return home. No bosses/enemies have been added downstairs. Existing saves with a prior win unlock the chamber already. Starting a new upper trial restores its floor.

OFFLINE CHECKS PASSED. UNITY COMPILATION, PLAYBACK AND AUDIBLE BALANCE ARE UNVERIFIED.
Swimming uses original head-raised looping actions pl00_130/pl00_131; original symbolic labels are unavailable and Unity appearance is unverified. Weapons use native family body/weapon motions and their own SES sounds. Exact original EST/SEQ event dispatch is not fully reconstructed. Earlier town/pub music and dedicated koto action identification remain unfinished. Read Repair-Report/README.md for the exact limits.

This cumulative update includes the previous original-asset remake dependencies. Existing unrelated project files and user saves are not packaged.
