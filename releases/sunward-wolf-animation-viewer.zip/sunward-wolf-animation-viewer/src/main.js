import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
const scene=new THREE.Scene();scene.background=new THREE.Color('#e8dfc8');scene.fog=new THREE.Fog('#e8dfc8',16,35);
scene.add(new THREE.HemisphereLight('#fff8e9','#85847c',1.8));
const key=new THREE.DirectionalLight('#fff2d7',2.1);key.position.set(-4,7,5);key.castShadow=true;key.shadow.mapSize.set(2048,2048);key.shadow.camera.left=-6;key.shadow.camera.right=6;key.shadow.camera.top=6;key.shadow.camera.bottom=-6;key.shadow.normalBias=.018;scene.add(key);
const fill=new THREE.DirectionalLight('#dce8ed',.65);fill.position.set(4,3,-4);scene.add(fill);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;document.body.append(renderer.domElement);
const camera=new THREE.PerspectiveCamera(34,innerWidth/innerHeight,.1,80);camera.position.set(-7.5,3.1,-.1);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,1,-.45);controls.enableDamping=true;controls.minDistance=3.5;controls.maxDistance=12;controls.maxPolarAngle=Math.PI*.48;
const floor=new THREE.Mesh(new THREE.PlaneGeometry(80,80),new THREE.MeshStandardMaterial({color:'#d2c7a9',roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.y=-.008;floor.receiveShadow=true;scene.add(floor);
const markers=new THREE.Group();scene.add(markers);for(let i=0;i<40;i++){const line=new THREE.Mesh(new THREE.PlaneGeometry(8,.012),new THREE.MeshBasicMaterial({color:'#aa9e83',transparent:true,opacity:.38,depthWrite:false}));line.rotation.x=-Math.PI/2;line.position.set(0,.001,(i-20)*.35);markers.add(line);}
const status=document.querySelector('#status'),select=document.querySelector('#animation'),scrub=document.querySelector('#scrub');
let model,mixer,action,clips=[],motion={},skeleton,paused=false,rate=1,groundDistance=0,fade=0,groundSpeed=0,last=performance.now();
const descriptions={Idle:'Relaxed breathing, a hanging tail and gentle fur movement.',Walk:'Four-beat walk. Planted paw travel and ground speed are matched.',Run:'Gallop with paired push-off, spine flexion and delayed tail motion.',JumpRise:'Upward jump pose.',JumpFall:'Falling pose with reaching legs.',Land:'Landing compression and recovery.'};
const studio={scene,camera,renderer,controls,get model(){return model},get mixer(){return mixer},get clips(){return clips},get action(){return action},get motion(){return motion},get groundSpeed(){return groundSpeed},get paused(){return paused}};window.wolfStudio=studio;
function choose(name){const clip=clips.find(c=>c.name===name);if(!clip)return;const next=mixer.clipAction(clip);next.reset().setEffectiveWeight(1).setEffectiveTimeScale(1).play();if(action&&action!==next)action.crossFadeTo(next,.65,false);for(const existing of clips){const a=mixer.clipAction(existing);if(a!==next&&a!==action)a.stop();}action=next;fade=.65;select.value=name;paused=false;document.querySelector('#play').textContent='Pause';document.querySelector('#play').setAttribute('aria-pressed','false');document.querySelector('#description').textContent=descriptions[name]||'Authored action pose · pause or scrub to inspect each stage.';}
studio.choose=choose;
studio.sample=(name,phase)=>{mixer.stopAllAction();action=mixer.clipAction(clips.find(c=>c.name===name));action.reset().setEffectiveWeight(1).play();action.time=action.getClip().duration*phase;mixer.update(0);model.updateMatrixWorld(true);paused=true;select.value=name;renderer.render(scene,camera);};
select.addEventListener('change',()=>choose(select.value));
document.querySelector('#play').onclick=()=>{paused=!paused;document.querySelector('#play').textContent=paused?'Play':'Pause';document.querySelector('#play').setAttribute('aria-pressed',String(paused));};
document.querySelector('#restart').onclick=()=>{if(action){action.time=0;mixer.update(0);groundDistance=0;}};
document.querySelector('#rate').oninput=e=>{rate=Number(e.target.value);document.querySelector('#rate-value').textContent=`${rate.toFixed(2).replace(/0+$/,'').replace(/\.$/,'')}×`;};
scrub.oninput=e=>{if(!action)return;paused=true;document.querySelector('#play').textContent='Play';action.time=Number(e.target.value)*action.getClip().duration;mixer.update(0);};
document.querySelector('#bones').onchange=e=>{if(skeleton)skeleton.visible=e.target.checked;};
for(const button of document.querySelectorAll('[data-view]'))button.onclick=()=>{const p={side:[-7.5,2.55,0],front:[0,2.7,-7.5],three:[-6,3.1,-4]}[button.dataset.view];camera.position.set(...p);controls.target.set(0,1,-.5);controls.update();};
try{
 const [asset,metadata]=await Promise.all([new GLTFLoader().loadAsync(`${import.meta.env.BASE_URL}models/wolf.glb`),fetch(`${import.meta.env.BASE_URL}motion.json`).then(r=>r.json())]);
 model=asset.scene;model.scale.setScalar(.34);model.rotation.y=Math.PI;scene.add(model);motion=metadata;clips=asset.animations;mixer=new THREE.AnimationMixer(model);
 const skins=[];model.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;o.frustumCulled=false;}if(o.isSkinnedMesh)skins.push(o);});
 for(const mesh of skins){const ink=new THREE.MeshBasicMaterial({color:'#62584b',side:THREE.BackSide});ink.onBeforeCompile=shader=>{shader.vertexShader=shader.vertexShader.replace('#include <skinning_vertex>','#include <skinning_vertex>\n transformed += normalize(objectNormal) * .013;');};const shell=new THREE.SkinnedMesh(mesh.geometry,ink);shell.bind(mesh.skeleton,mesh.bindMatrix);shell.position.copy(mesh.position);shell.quaternion.copy(mesh.quaternion);shell.scale.copy(mesh.scale);shell.frustumCulled=false;mesh.parent.add(shell);}
 skeleton=new THREE.SkeletonHelper(model);skeleton.visible=false;scene.add(skeleton);
 const order=['Idle','Walk','Run','Jump','JumpRise','JumpFall','Land'];clips.sort((a,b)=>(order.includes(a.name)?order.indexOf(a.name):99)-(order.includes(b.name)?order.indexOf(b.name):99)||a.name.localeCompare(b.name));
 select.replaceChildren(...clips.map(c=>{const option=document.createElement('option');option.value=c.name;option.textContent=c.name.replace(/([a-z])([A-Z])/g,'$1 $2');return option;}));select.disabled=false;choose('Idle');status.textContent='Wolf only · drag to orbit';
}catch(error){status.textContent=`Could not load the viewer: ${error.message}`;console.error(error);}
function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;if(mixer&&!paused){mixer.update(dt*rate);fade=Math.max(0,fade-dt);const target=motion[action.getClip().name]?.ground_speed||0;groundSpeed=THREE.MathUtils.damp(groundSpeed,target,fade>0?6:25,dt);groundDistance+=groundSpeed*dt*rate;if(action)scrub.value=(action.time/action.getClip().duration)%1;}markers.position.z=document.querySelector('#ground').checked?groundDistance%.35:0;controls.update();renderer.render(scene,camera);requestAnimationFrame(frame);}requestAnimationFrame(frame);
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
