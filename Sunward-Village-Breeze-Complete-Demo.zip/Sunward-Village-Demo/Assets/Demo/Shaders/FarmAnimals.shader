Shader "VillageDemo/Original Farm Animals" {
 Properties { _MainTex("Original painted animal",2D)="white"{} _Color("Pigment",Color)=(1,1,1,1) _Cutoff("Brush alpha",Range(0,1))=.30 }
 SubShader {
  Tags { "RenderType"="TransparentCutout" "Queue"="AlphaTest" }
  Cull Back
  Pass {
   Tags { "LightMode"="ForwardBase" }
   CGPROGRAM
   #pragma target 3.0
   #pragma vertex vert
   #pragma fragment frag
   #pragma multi_compile_fwdbase
   #include "UnityCG.cginc"
   #include "Lighting.cginc"
   #include "AutoLight.cginc"
   sampler2D _MainTex;float4 _Color;float _Cutoff;
   struct appdata { float4 vertex:POSITION;float3 normal:NORMAL;float2 uv:TEXCOORD0;float4 color:COLOR;float2 texcoord1:TEXCOORD1; };
   struct v2f { float4 pos:SV_POSITION;float2 uv:TEXCOORD0;float3 normal:TEXCOORD1;float4 color:COLOR;SHADOW_COORDS(2) };
   v2f vert(appdata v) { v2f o;o.pos=UnityObjectToClipPos(v.vertex);o.uv=v.uv;o.normal=UnityObjectToWorldNormal(v.normal);o.color=v.color;TRANSFER_SHADOW(o);return o; }
   fixed4 frag(v2f i):SV_Target { fixed4 c=tex2D(_MainTex,i.uv)*_Color;clip(c.a-_Cutoff);float shade=saturate(dot(normalize(i.normal),normalize(_WorldSpaceLightPos0.xyz)));c.rgb*=i.color.rgb*(.82+.18*shade*SHADOW_ATTENUATION(i));c.a=1;return c; }
   ENDCG
  }
  Pass {
   Tags { "LightMode"="ShadowCaster" }
   ZWrite On Cull Back
   CGPROGRAM
   #pragma vertex vertShadow
   #pragma fragment fragShadow
   #pragma multi_compile_shadowcaster
   #include "UnityCG.cginc"
   sampler2D _MainTex;float _Cutoff;
   struct input { float4 vertex:POSITION;float3 normal:NORMAL;float2 uv:TEXCOORD0; };
   struct output { V2F_SHADOW_CASTER;float2 uv:TEXCOORD1; };
   output vertShadow(input v) { output o;o.uv=v.uv;TRANSFER_SHADOW_CASTER_NORMALOFFSET(o);return o; }
   float4 fragShadow(output i):SV_Target { clip(tex2D(_MainTex,i.uv).a-_Cutoff);SHADOW_CASTER_FRAGMENT(i) }
   ENDCG
  }
 }
 Fallback Off
}
