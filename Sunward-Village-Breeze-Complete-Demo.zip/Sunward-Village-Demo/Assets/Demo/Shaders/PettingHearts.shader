Shader "VillageDemo/Petting Ink Hearts" {
 Properties { _MainTex("Painted heart",2D)="white"{} _Opacity("Fade",Range(0,1))=1 }
 SubShader { Tags {"Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True"} Cull Off ZWrite Off Blend SrcAlpha OneMinusSrcAlpha
 Pass { CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 sampler2D _MainTex;float _Opacity;
 struct input {float4 vertex:POSITION;float2 uv:TEXCOORD0;};struct output {float4 pos:SV_POSITION;float2 uv:TEXCOORD0;};
 output vert(input v){output o;o.pos=UnityObjectToClipPos(v.vertex);o.uv=v.uv;return o;}
 fixed4 frag(output i):SV_Target{fixed4 c=tex2D(_MainTex,i.uv);c.a*=_Opacity;return c;}
 ENDCG }
 } Fallback Off
}
