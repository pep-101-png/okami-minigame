@echo off
setlocal
set "DEMO_PROJECT=%~dp0Sunward-Village-Demo"
if not exist "%DEMO_PROJECT%\.sunward-village-demo" goto missing
set "DEMO_UNITY_EDITOR=%ProgramFiles%\Unity\Hub\Editor\6000.6.6f1\Editor\Unity.exe"
if defined SUNWARD_DEMO_UNITY_EDITOR set "DEMO_UNITY_EDITOR=%SUNWARD_DEMO_UNITY_EDITOR%"
if not exist "%DEMO_UNITY_EDITOR%" goto missing
start "Sunward Separate Village Demo" "%DEMO_UNITY_EDITOR%" -projectPath "%DEMO_PROJECT%"
exit /b 0
:missing
echo Add the extracted Sunward-Village-Demo folder as a NEW project in Unity Hub.
echo Open it with Unity 6000.6.6f1 and press Play. Do not copy its Assets into your game.
pause
exit /b 1
