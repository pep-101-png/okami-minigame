@echo off
setlocal
set "DEMO_PROJECT=%~dp0Sunward-Village-Demo"
if not exist "%DEMO_PROJECT%\.sunward-village-demo" goto wrongfolder
set "DEMO_UNITY_EDITOR=%ProgramFiles%\Unity\Hub\Editor\6000.6.6f1\Editor\Unity.exe"
if defined SUNWARD_DEMO_UNITY_EDITOR set "DEMO_UNITY_EDITOR=%SUNWARD_DEMO_UNITY_EDITOR%"
if not exist "%DEMO_UNITY_EDITOR%" goto missingeditor
echo Building ONLY the separate village demo. Your Sunward game is not opened or changed.
echo First import can take several minutes. Progress is in the demo's Build.log.
"%DEMO_UNITY_EDITOR%" -batchmode -quit -projectPath "%DEMO_PROJECT%" -executeMethod SunwardVillageDemo.Editor.DemoBuild.BuildWindows -logFile "%DEMO_PROJECT%\Build.log"
if errorlevel 1 goto failed
if not exist "%DEMO_PROJECT%\Build\SunwardVillageDemo.exe" goto failed
start "" "%DEMO_PROJECT%\Build\SunwardVillageDemo.exe"
exit /b 0
:wrongfolder
echo Keep this script beside the extracted Sunward-Village-Demo folder. The separate-demo marker is missing.
pause
exit /b 1
:missingeditor
echo Unity 6000.6.6f1 was not found in its usual Unity Hub location.
echo Add the separate Sunward-Village-Demo folder in Unity Hub and open it with 6000.6.6f1.
echo You can press Play there, or use Village Demo / Build Windows player.
echo For a custom editor location, set SUNWARD_DEMO_UNITY_EDITOR to that Unity.exe path.
pause
exit /b 1
:failed
echo The demo did not build. Open the demo folder's Build.log for the exact Unity error.
echo Unity licensing or Windows Standalone support may need setup in Unity Hub.
echo No executable is claimed unless the build reports success.
pause
exit /b 1
