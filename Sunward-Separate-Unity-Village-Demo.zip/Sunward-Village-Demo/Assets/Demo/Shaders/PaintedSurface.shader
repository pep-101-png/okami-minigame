Shader "VillageDemo/Painted Surface" {
 Properties {
  _MainTex ("Painted artwork", 2D) = "white" {}
  _Color ("Paint tint", Color) = (1,1,1,1)
  _UVMatrix ("UV matrix", Vector) = (1,0,0,1)
  _UVOffset ("UV offset", Vector) = (0,0,0,0)
  _RepeatUV ("Repeat inside atlas panel", Float) = 0
  _Cutoff ("Cutout threshold", Range(0,1)) = 0
  _WindStrength ("Soft foliage breeze", Float) = 0
  _WaterMode ("Water animation", Float) = 0
  _FlowTime ("Flow time", Float) = 0
  _FlowSpeed ("Flow speed", Vector) = (0.07,0,0,0)
  _WaveStrength ("Surface ripple", Float) = 0.018
 }
 SubShader {
  Tags { "RenderType"="Opaque" "Queue"="Geometry" }
  Cull Off
  Pass {
   Tags { "LightMode"="ForwardBase" }
   CGPROGRAM
   #pragma target 3.0
   #pragma vertex vert
   #pragma fragment frag
   #pragma multi_compile_fwdbase
   #include "UnityCG.cginc"
   #include "Lighting.cginc"
   #include "AutoLight.cginc"
   sampler2D _MainTex; float4 _Color, _UVMatrix, _UVOffset, _FlowSpeed;
   float _RepeatUV, _Cutoff, _WindStrength, _WaterMode, _FlowTime, _WaveStrength;
   struct appdata { float4 vertex:POSITION; float3 normal:NORMAL; float2 uv:TEXCOORD0; float4 color:COLOR; float2 texcoord1:TEXCOORD1; };
   struct v2f { float4 pos:SV_POSITION; float2 uv:TEXCOORD0; float3 normal:TEXCOORD1; SHADOW_COORDS(2) };
   v2f vert(appdata v) {
    v2f o; float3 world = mul(unity_ObjectToWorld,v.vertex).xyz;
    float sway = sin(_Time.y*1.15+world.x*.8+world.z*.47)*_WindStrength*v.color.a;
    v.vertex.x += sway; v.vertex.z += sway*.38;
    v.vertex.y += _WaterMode*_WaveStrength*sin(world.x*2.1+world.z*1.6+_FlowTime*1.7)*v.color.a;
    o.pos=UnityObjectToClipPos(v.vertex); o.uv=v.uv; o.normal=UnityObjectToWorldNormal(v.normal); TRANSFER_SHADOW(o); return o;
   }
   fixed4 frag(v2f i):SV_Target {
    float2 uv=i.uv+_WaterMode*_FlowTime*_FlowSpeed.xy;
    if (_RepeatUV>.5 || _WaterMode>.5) uv=frac(uv);
    uv=float2(dot(_UVMatrix.xy,uv),dot(_UVMatrix.zw,uv))+_UVOffset.xy;
    fixed4 c=tex2D(_MainTex,uv)*_Color; clip(c.a-_Cutoff);
    float shade=saturate(dot(normalize(i.normal),normalize(_WorldSpaceLightPos0.xyz)));
    float shadow=SHADOW_ATTENUATION(i); c.rgb*=.73+.27*shade*shadow; c.a=1; return c;
   }
   ENDCG
  }
  UsePass "Legacy Shaders/VertexLit/SHADOWCASTER"
 }
 Fallback "Diffuse"
}
