using System.Collections.Generic;
using UnityEngine;

namespace SunwardVillageDemo
{
    public sealed class DemoWaterMotion : MonoBehaviour
    {
        public static DemoWaterMotion Active { get; private set; }
        public bool Animated = true;
        readonly List<Renderer> surfaces = new List<Renderer>();
        MaterialPropertyBlock properties;
        float phase;
        static readonly int FlowTime = Shader.PropertyToID("_FlowTime");
        void Awake()
        {
            Active = this; properties = new MaterialPropertyBlock();
            CollectSurfaces();
        }
        void Start() { if (surfaces.Count == 0) CollectSurfaces(); }
        void CollectSurfaces()
        {
            surfaces.Clear();
            foreach (Renderer renderer in FindObjectsByType<Renderer>(FindObjectsSortMode.None))
            {
                foreach (Material material in renderer.sharedMaterials)
                {
                    if (material != null && material.HasProperty("_WaterMode") && material.GetFloat("_WaterMode") > .5f)
                    { surfaces.Add(renderer); break; }
                }
            }
        }
        void Update()
        {
            if (Animated) phase += Time.deltaTime;
            foreach (Renderer renderer in surfaces)
            {
                if (renderer == null) continue;
                renderer.GetPropertyBlock(properties); properties.SetFloat(FlowTime, phase); renderer.SetPropertyBlock(properties);
            }
        }
        void OnDestroy() { if (Active == this) Active = null; }
    }
}
