# Continue the separate Sunward asset library

The first nine representative prototypes are complete for review. The full library is not complete. Do not modify Unity or the approved R2 houses.

Read PROGRESS.md, progress.json, Inventory/README.md, Sources.json and References/category-reference-map.json. Exact component IDs and locations are in scene-asset-bindings.csv/json. Some numeric legacy identities remain unconfirmed; do not invent semantic labels.

The delivered .blend files are authoritative. They have packed textures, three review cameras and separate model/studio collections. Do not rebuild them blindly: the final geometry/material/UV corrections are later than the initial generator. The cloud authoring work is in /workspace/sunward-environment-library/source, with generation, visual corrections and validation scripts; some correction scripts are intentionally stateful. The protected original R2 house files are outside this folder.

Continue category by category from the checklist: remaining tree/plant and cliff families, pond/waterfall and river sections, lantern/fence/sign variants, bridge/mill/shrine/food-hall/building work and props, then the seven recorded NPC roles with their existing functions. No original NPC rig was decoded. New NPC meshes/rigging must be labelled as new work.

Keep original texture IDs and distinguish new UV assignments from confirmed original model texture indices. New nature atlas art and approved-house art are separately labelled. Never present the comparison's approximate Blender rendering of Sunward as a Unity screenshot. New prototypes must be rendered and inspected from multiple angles, reopened without loose image paths, checked against protected hashes and added to the catalogue before delivery.
