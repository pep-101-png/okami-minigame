# Sunward saved-project inventory

Snapshot: `81f56a261ae50c641b4279ca733183bba34aee4a` on `fix/windflower-player-review-3`. One saved Windflower scene. No Unity files changed.

2319 non-meta Assets files; 776 materials; 19 prefab templates; 2087 visible renderer bindings; 685 distinct visible mesh references.

A renderer binding is not a complete prop. See exact hierarchy, Unity XYZ location, fileID, GUID and materials in scene-asset-bindings.csv/json. All disabled/template versions are retained. Imported wolf FBX internals, final shaders and live runtime composition need Unity; this is not a runtime screenshot audit.

## Discovered content

- Nature: rooted olive/cherry/pine trees, canopies, legacy bamboo including TownV3-406 / Valley-405, seven sculpted bamboo clumps, groundcover, flowers, lotus, reeds, rock variants, cliffs and source cliff.
- Terrain/water: landscape Valley-751, painted path surfaces, approach flagstones, river Valley-794, recessed pond, waterfall sheet, spring channel, foam and paddle spray.
- Village: joined timber/plaster houses and roof variants, Amaterasu home, food hall and shrine interiors, two bridges, mill annex, wheel and gears, bell trial gate, fences, signs, market stalls, shelves and produce.
- Lighting/decoration: stone lanterns, warm lights, festival coloured papers, cords, noren, window paper/lattice, mirror, tatami, futon, rest cushions, bowls/cups, violin and bow, practice swords, training dummies, arena logs and ring ends.
- Characters: Gardener, Merchant, Elder, Samurai, ShrineMaiden, Geisha, Chef. Existing functions include strolling, conversation, eating, violin performance and training. Enemy prefab types: wisp, reed, heavy, ranged, elite, boss; not original decoded NPC rigs.
- Dynamic objects: trial barrier, enemy visuals, ink projectiles, impact rings, sundial flame/orbits/trails, collectibles and Shiranui preview. Audited source construction sites separately; player/wolf/weapons protected from recreation.

## Categories (navigation, not original metadata)

- Plants and Flowers: 634 visible renderer bindings.
- Other Sunward Assets: 133 visible renderer bindings.
- Lanterns and Decorations: 122 visible renderer bindings.
- NPCs: 36 visible renderer bindings.
- Unclassified: 154 visible renderer bindings.
- Rocks and Terrain: 527 visible renderer bindings.
- Protected Player and Weapons: 30 visible renderer bindings.
- Buildings and Markets: 351 visible renderer bindings.
- Water and Rivers: 4 visible renderer bindings.
- Trees and Bamboo: 95 visible renderer bindings.
- Ground and Paths: 1 visible renderer bindings.

## Files

- scene-asset-bindings.csv/json: all render/light/audio bindings, IDs, locations, active state, matrices, materials.
- project-assets.csv/json: every non-meta Assets file, bytes, LFS-pointer state and saved-scene reachability.
- material-catalogue.json: every material, shader reference, textures and properties, per-binding usage.
- asset-families.json: provisional grouping for progress tracking; exact component IDs remain authoritative.
- prefab-instances.json, npc-roles.json, script-bindings.json, runtime-construction.json and unresolved-references.json.

Classification uses names and known material kinds. Legacy numeric mesh names without trustworthy semantics remain explicitly unclassified; they are not dropped. Composite-prop boundaries require manual visual judgement. This snapshot cannot see unuploaded changes on the PC.
